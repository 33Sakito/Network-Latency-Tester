import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class NetworkLatencyTester extends JFrame {

    private JTextField hostnameField;
    private JTextField countField;
    private JTextArea resultArea;

    public NetworkLatencyTester() {
        setTitle("网络延迟测试工具");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 创建输入框和按钮
        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        hostnameField = new JTextField(20);
        countField = new JTextField(5);
        JButton testButton = new JButton("测试延迟");
        inputPanel.add(new JLabel("目标主机:"));
        inputPanel.add(hostnameField);
        inputPanel.add(new JLabel("测量次数:"));
        inputPanel.add(countField);
        inputPanel.add(new JLabel()); // 空标签占位
        inputPanel.add(testButton);
        add(inputPanel, BorderLayout.NORTH);

        // 创建结果显示区域
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        add(scrollPane, BorderLayout.CENTER);

        // 添加按钮点击事件
        testButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String hostname = hostnameField.getText();
                int count = Integer.parseInt(countField.getText());
                testLatency(hostname, count);
            }
        });
    }

    private void testLatency(String hostname, int count) {
        try {
            InetAddress inetAddress = InetAddress.getByName(hostname);
            resultArea.append("测试网络延迟到 " + hostname + "...\n");

            long totalLatency = 0;
            for (int i = 0; i < count; i++) {
                long startTime = System.currentTimeMillis();
                boolean isReachable = inetAddress.isReachable(5000); // 5秒超时
                long endTime = System.currentTimeMillis();

                if (isReachable) {
                    long latency = endTime - startTime;
                    totalLatency += latency;
                    resultArea.append("测量 " + (i + 1) + ": " + latency + " ms\n");
                } else {
                    resultArea.append("测量 " + (i + 1) + ": 主机不可达。\n");
                }
            }

            if (count > 0) {
                double averageLatency = totalLatency / (double) count;
                resultArea.append("平均延迟: " + averageLatency + " ms\n");
            }
        } catch (UnknownHostException e) {
            resultArea.append("未知主机: " + hostname + "\n");
        } catch (Exception e) {
            resultArea.append("发生错误: " + e.getMessage() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new NetworkLatencyTester().setVisible(true);
            }
        });
    }
}